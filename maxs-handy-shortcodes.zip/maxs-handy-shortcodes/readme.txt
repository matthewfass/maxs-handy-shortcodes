=== Shortcodes by Max ===

These are my plugins that will help you!

== Description ==

These are my plugins that will help you!

== Installation ==

Upload the Shortcodes by Max plugin to your blog, Activate it, then use the shortcodes

== Changelog ==

= 0.0.1 =

Initial build

